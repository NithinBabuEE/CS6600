//***********************************************************************
// CS6600 Assignment-4 (Jul-Nov 2021)
//
// File name: predictor.cc
//
// Team members: Karthikeyan R (EE18B015)
//               Nithin Babu   (EE18B021)
//
// Description: - File that contains meber function definitions to
//                of the PREDICTOR class for Tournament Branch
//                Prediction.
//                 - GetPrediction()   -> Make the branch prediction
//                 - UpdatePrediction()-> Update branch prediction unit
//                                        values
//***********************************************************************

#include "predictor.h"
#include <math.h>


//
// Initializing all the table entires with 0 in the constructor
//
PREDICTOR::PREDICTOR(void){
    
    ghr = 0;

    for(UINT32 ii=0; ii< LHT_SIZE; ii++){
        lht[ii] = 0;
    }
    for(UINT32 ii=0; ii< LPT_SIZE; ii++){
        lpt[ii] = 0;
    }
    for(UINT32 ii=0; ii< GPT_SIZE; ii++){
        gpt[ii] = 0;
        cpt[ii] = 0;
    }
  
}


//
// GetPrediction member function
// Arguments: (UINT64) -> Program Counter
// Returns  : (bool)   -> Branch taken or not taken
//
bool   PREDICTOR::GetPrediction(UINT64 PC){

    bool local_prediction, global_prediction, final_prediction;

    // Extracting the Program Counter LSBs to index into the Local History Table
    UINT64 lht_index = (PC << (64 - PC_INDEX_SIZE)) >> (64 - PC_INDEX_SIZE);


    UINT32 lpt_index = lht[lht_index];  // Local History Table value
    UINT32 lpt_val = lpt[lpt_index];    // Local Prediction Table value
    UINT32 gpt_val = gpt[ghr];          // Global Prediction Table value
    UINT32 cpt_val = cpt[ghr];          // Choice Prediction Table value
    
    //
    // Making local prediction based on the value in Local Prediction Table
    //
    if(lpt_val > LPT_THRESHOLD)
        local_prediction = 1;
    else
        local_prediction = 0;

    //
    // Making global prediction based on the value in Global Prediction Table
    //
    if(gpt_val > GPT_THRESHOLD)
        global_prediction = 1;
    else
        global_prediction = 0;
    
    //
    // If global prediction and local prediction are different Choice Prediction Table is used
    // to make the final prediction
    //
    if(global_prediction != local_prediction){
        if(cpt_val > CPT_THRESHOLD)
            final_prediction = global_prediction;
        else
            final_prediction = local_prediction;
    }
    else
        final_prediction = global_prediction;
    
    //
    // Return the final prediction
    // 1 -> Branch taken
    // 0 -> Branch not taken
    //
    return final_prediction;
}

//
// UpdatePredictor member function
// Arguments used:
//  - (UINT64) PC       -> Program Counter
//  - (bool) resolveDir -> Actual branch direction
//  - (bool) predDir    -> Predicted branch direction
//
void  PREDICTOR::UpdatePredictor(UINT64 PC, OpType opType, bool resolveDir, bool predDir, UINT64 branchTarget){

    bool local_prediction, global_prediction, choice_taken;

    // Extracting the Program Counter LSBs to index into the Local History Table
    UINT64 lht_index = (PC << (64 - PC_INDEX_SIZE)) >> (64 - PC_INDEX_SIZE);  
    
    UINT32 lpt_index = lht[lht_index];  // Local History Table value
    UINT32 lpt_val = lpt[lpt_index];    // Local Prediction Table value
    UINT32 gpt_val = gpt[ghr];          // Global Prediction Table value
    UINT32 cpt_val = cpt[ghr];          // Choice Prediction Table value
    
    UINT32 ghr_temp;                    // Temporary variable to hold updated Global History Register value

    if(lpt_val > LPT_THRESHOLD)
        local_prediction = 1;
    else
        local_prediction = 0;

    if(gpt_val > GPT_THRESHOLD)
        global_prediction = 1;
    else
        global_prediction = 0;

    //        
    // Updating Choice Prediction Table value if local prediction and global prediction
    // do not match
    //
    if(global_prediction != local_prediction){

        if(predDir == global_prediction){

            // Increment the choice prediction table value if global prediction is a hit
            if(resolveDir == predDir && cpt_val < MAX_CPT_VAL)
                cpt_val++;

            // Decrement the choice prediction table value if global prediction is a miss
            else{
                if(cpt_val > 0)
                    cpt_val--; 
            }
        }

        else{

            // Decrement the choice prediction table value if local prediction is a miss
            if(resolveDir == predDir && cpt_val > 0)
                cpt_val--;

            // Increment the choice prediction table value if local prediction is a miss
            else{
                if(cpt_val < MAX_CPT_VAL)
                    cpt_val++;
            }
        }       
    }

    //
    // Update the Local Prediction Table and Global Prediction Table values
    //
    if(resolveDir){
        if(lpt_val < MAX_LPT_VAL && gpt_val < MAX_GPT_VAL){
            lpt_val++;
            gpt_val++;
         }

        // Update Local History Table and Global Histrory Register values
        lpt_index = (lpt_index >> 1) | (UINT64)pow(2,(LHT_REG_WIDTH-1));
        ghr_temp  = (ghr >> 1) | (UINT64)pow(2,(GHR_REG_WIDTH-1));
    }
    else{
        if(lpt_val > 0 && gpt_val > 0){
            lpt_val--;
            gpt_val--;
        }
        lpt_index = lpt_index >> 1;
        ghr_temp  = ghr >> 1;
    }  

    // Write all the updated values into the tables
    lht[lht_index] = lpt_index;
    lpt[lpt_index] = lpt_val;
    gpt[ghr]       = gpt_val;
    cpt[ghr]       = cpt_val;
    ghr            = ghr_temp;
}


void    PREDICTOR::TrackOtherInst(UINT64 PC, OpType opType, bool branchDir, UINT64 branchTarget){

  // This function is called for instructions which are not
  // conditional branches, just in case someone decides to design
  // a predictor that uses information from such instructions.
  // We expect most contestants to leave this function untouched.

  return;
}

//*********************************************** END OF FILE *******************************************************