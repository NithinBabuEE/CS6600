//***********************************************************************
// CS6600 Assignment-4 (Jul-Nov 2021)
//
// File name: predictor.h
//
// Team members: Karthikeyan R (EE18B015)
//               Nithin Babu   (EE18B021)
//
// Description: - Header file that contains parameter and class
//                definitions needed for Tournament Branch Prediction
//***********************************************************************
#ifndef _PREDICTOR_H_
#define _PREDICTOR_H_

#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <inttypes.h>
#include <math.h>
#include "utils.h"
#include <vector>

// Define Tournament Branch Predictor Unit parameters
#define PC_INDEX_SIZE 10                                     // Number of LSBs of Program Counter used to index the Local History Table
#define LHT_SIZE (int)pow(2,PC_INDEX_SIZE)                   // Local History Table size
#define LHT_REG_WIDTH 12                                     // Local History Table entry size
#define LPT_SIZE (int)pow(2,LHT_REG_WIDTH)                   // Local Prediction Table size
#define LPT_REG_WIDTH 4                                      // Local Prediction Table entry size
#define GHR_REG_WIDTH 14                                     // Global History Register size
#define GPT_SIZE (int)pow(2,GHR_REG_WIDTH)                   // Global Prediction Table size
#define GPT_REG_WIDTH 4                                      // Global Prediction Tabe enrty size
#define CPT_SIZE GPT_SIZE                                    // Choice Prediction Table size
#define CPT_REG_WIDTH 2                                      // Choice Perdiction Table entry size
#define LPT_THRESHOLD (int)(pow(2,(LPT_REG_WIDTH-1)) - 1)    // Local Prediction threshold value
#define GPT_THRESHOLD (int)(pow(2,(GPT_REG_WIDTH-1)) - 1)    // Global Prediction threshold value
#define CPT_THRESHOLD (int)(pow(2,(CPT_REG_WIDTH-1)) - 1)    // Choice prediction threshold value
#define MAX_LPT_VAL (int)pow(2,LPT_REG_WIDTH)                // Maximum Local Prediction Table value
#define MAX_GPT_VAL (int)pow(2,GPT_REG_WIDTH)                // Maximum Global Prediction Table Value
#define MAX_CPT_VAL (int)pow(2,CPT_REG_WIDTH)                // Maximum Choice Prediction Table value


class PREDICTOR{

  // PREDICTOR class definition for Tournament Branch Prediction

 private:
  UINT32  ghr;                  // Global history register
  UINT32  lht[LHT_SIZE];        // Local history table
  UINT32  lpt[LPT_SIZE];        // Local prediction table
  UINT32  gpt[GPT_SIZE];        // Global prediction table
  UINT32  cpt[CPT_SIZE];        // Choice Prediction Table

 public:
  PREDICTOR(void);

  // Member function to make the branch prediction
  bool    GetPrediction(UINT64 PC);

  // Member function to update the branch prediction unit table values
  void    UpdatePredictor(UINT64 PC, OpType opType, bool resolveDir, bool predDir, UINT64 branchTarget);
  void    TrackOtherInst(UINT64 PC, OpType opType, bool branchDir, UINT64 branchTarget);
  
};

#endif

//*********************************************** END OF FILE *******************************************************